#pragma once

#include <ntifs.h>
#include <ntimage.h>



