#pragma once

int downloadSymbolsTest();