#pragma once

void WriteLog(bool bOutput, bool bWantProcessName, const char* fmt, ...);