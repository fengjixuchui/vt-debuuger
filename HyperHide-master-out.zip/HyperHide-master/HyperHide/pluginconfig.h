#pragma once
#define PLUGIN_NAME "HyperHide"
#define PLUGIN_VERSION 1
